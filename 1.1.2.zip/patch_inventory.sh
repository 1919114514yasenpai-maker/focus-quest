#!/bin/bash
sed -i 's/onInsertGem, onTransferEnhancements, isQuestActive } = props;/onInsertGem, onTransferEnhancements, isQuestActive, guildName, onEngraveItem } = props;/' src/components/Inventory.tsx

# In ItemIcon or item detail rendering, we need to show the engraving.
