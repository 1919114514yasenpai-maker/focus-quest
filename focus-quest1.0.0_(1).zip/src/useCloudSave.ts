import { useEffect, useState, useCallback } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, signInWithGoogle, logoutUser, testConnection, handleFirestoreError, OperationType } from './firebase';
import { SaveData } from './types';
import { sanitizeSaveData } from './saveManager';

export function useCloudSave(
  saveData: SaveData,
  onCloudDataLoaded: (cloudData: SaveData) => void
) {
  const [user, setUser] = useState<User | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);

  // Test connection on boot
  useEffect(() => {
    testConnection();
  }, []);

  // Listen to auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setLoadingAuth(false);

      if (currentUser) {
        // Attempt to load cloud save on sign in
        try {
          setSyncing(true);
          const saveDocRef = doc(db, 'users', currentUser.uid, 'saves', 'default');
          const snapshot = await getDoc(saveDocRef);

          if (snapshot.exists()) {
            const data = snapshot.data();
            const sanitized = sanitizeSaveData(data);
            onCloudDataLoaded(sanitized);
            setLastSyncedAt(data.updatedAt ? new Date(data.updatedAt).toLocaleTimeString() : 'クラウドから同期済み');
          } else {
            // First time user logged in: upload local save data to cloud
            await setDoc(saveDocRef, {
              stats: saveData.stats,
              equipment: saveData.equipment,
              inventory: saveData.inventory,
              updatedAt: new Date().toISOString(),
            });
            setLastSyncedAt(new Date().toLocaleTimeString());
          }
        } catch (err) {
          console.error("Cloud load error:", err);
          setSyncError("クラウドデータのロードに失敗しました。");
          handleFirestoreError(err, OperationType.GET, `users/${currentUser.uid}/saves/default`);
        } finally {
          setSyncing(false);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Sync to cloud
  const saveToCloud = useCallback(async (dataToSave: SaveData) => {
    if (!user) return;

    try {
      setSyncing(true);
      setSyncError(null);
      const saveDocRef = doc(db, 'users', user.uid, 'saves', 'default');
      const now = new Date().toISOString();
      await setDoc(saveDocRef, {
        stats: dataToSave.stats,
        equipment: dataToSave.equipment,
        inventory: dataToSave.inventory,
        updatedAt: now,
      });
      setLastSyncedAt(new Date(now).toLocaleTimeString());
    } catch (err) {
      console.error("Cloud save error:", err);
      setSyncError("クラウド同期エラー");
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/saves/default`);
    } finally {
      setSyncing(false);
    }
  }, [user]);

  const handleLogin = async () => {
    try {
      setSyncError(null);
      await signInWithGoogle();
    } catch (err) {
      console.error("Login failed:", err);
      setSyncError("ログインに失敗しました");
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      setLastSyncedAt(null);
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  return {
    user,
    loadingAuth,
    syncing,
    lastSyncedAt,
    syncError,
    saveToCloud,
    handleLogin,
    handleLogout,
  };
}
